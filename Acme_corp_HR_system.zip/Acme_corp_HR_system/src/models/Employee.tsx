export default class Employee {

	constructor(public firstname:string, public lastname:string, public jobposition:["frontend","back","test","architect"], public workingtime:['full','part'], public id:number ) {}
}